#!/bin/bash
# سكريبت الرفع التلقائي إلى مستودع GitHub
# نظام الوجيه لإدارة العيادات

REPO_URL="https://github.com/hassan-wajih-ai/al-wagih-clinic.git"

echo "=================================================="
echo "🚀 جاري تهيئة ورفع مشروع الوجيه إلى GitHub..."
echo "=================================================="

# التأكد من المجلد الحالي
cd "$(dirname "$0")" || exit

# تهيئة مستودع Git محلياً
git init

# إضافة جميع الملفات
git add .

# إنشاء أول Commit
git commit -m "Initial commit: Al Wagih for Clinic Management System v1.0"

# ضبط الفرع الرئيسي main
git branch -M main

# ربط المستودع البعيد
git remote remove origin 2>/dev/null
git remote add origin "$REPO_URL"

# رفع الملفات
echo "جاري الرفع إلى: $REPO_URL"
git push -u origin main

echo "=================================================="
echo "✅ تم الرفع بنجاح إلى GitHub!"
echo "=================================================="
